define({ "api": [
  {
    "type": "get",
    "url": "/api/v1/downloadxlsx",
    "title": "下载配置数据",
    "group": "channel",
    "name": "DownloadXlsx",
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/getchannelsnap",
    "title": "获取通道快照",
    "group": "channel",
    "name": "GetChannelSnap",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "realtime",
            "defaultValue": "false",
            "description": "<p>实时快照</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK\nimage/jpeg 格式, http body 为图片数据",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关"
  },
  {
    "type": "get",
    "url": "/api/v1/getchannelstream",
    "title": "获取通道直播链接",
    "group": "channel",
    "name": "GetChannelStream",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "RTMP",
              "HLS",
              "FLV",
              "WS_FLV",
              "RTSP",
              "WEBRTC"
            ],
            "optional": true,
            "field": "protocol",
            "description": "<p>直播协议</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.URL",
            "description": "<p>直播链接</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.ChannelName",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.SnapURL",
            "description": "<p>通道快照</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.NumOutputs",
            "description": "<p>在线人数</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "LiveQing.Body.AudioEnable",
            "description": "<p>是否音频开启</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "LiveQing.Body.Ondemand",
            "description": "<p>是否按需直播</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "LiveQing.Body.Recording",
            "description": "<p>是否正在实时录像</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.SourceVideoCodecName",
            "description": "<p>原始视频编码</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.SourceVideoWidth",
            "description": "<p>原始视频宽</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.SourceVideoHeight",
            "description": "<p>原始视频高</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.SourceVideoFrameRate",
            "description": "<p>原始视频帧率</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.SourceAudioCodecName",
            "description": "<p>原始音频编码</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.SourceAudioSampleRate",
            "description": "<p>原始音频采样率</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.OSD",
            "description": "<p>视频上叠加的文字</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.DeviceType",
            "description": "<p>接入协议:RTSP,ONVIF...</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关"
  },
  {
    "type": "get",
    "url": "/api/v1/getchannels",
    "title": "获取通道信息",
    "group": "channel",
    "name": "GetChannels",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "channel",
            "description": "<p>获取指定通道号的通道信息</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": true,
            "field": "online",
            "defaultValue": "true,false",
            "description": "<p>通道在线状态</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": true,
            "field": "streaming",
            "defaultValue": "true,false",
            "description": "<p>通道取流状态</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "start",
            "description": "<p>分页开始,从零开始</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "limit",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "sort",
            "description": "<p>排序字段</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "ascending",
              "descending"
            ],
            "optional": true,
            "field": "order",
            "description": "<p>排序顺序</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "q",
            "description": "<p>查询参数</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.ChannelCount",
            "description": "<p>通道总数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "LiveQing.Body.Channels",
            "description": "<p>通道列表</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.Channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.Name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "LiveQing.Body.Channels.Online",
            "description": "<p>在线状态</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.NumOutputs",
            "description": "<p>在线人数</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.RecordReserveDays",
            "description": "<p>录像保存天数</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.SnapURL",
            "description": "<p>快照链接</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "LiveQing.Body.Channels.AudioEnable",
            "description": "<p>是否开启音频</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "LiveQing.Body.Channels.Ondemand",
            "description": "<p>是否按需直播</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "LiveQing.Body.Channels.Streaming",
            "description": "<p>是否正在取流</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "LiveQing.Body.Channels.Recording",
            "description": "<p>是否正在实时录像</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.SourceVideoCodecName",
            "description": "<p>原始视频编码</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.SourceVideoWidth",
            "description": "<p>原始视频宽</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.SourceVideoHeight",
            "description": "<p>原始视频高</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.SourceVideoFrameRate",
            "description": "<p>原始视频帧率</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.SourceAudioCodecName",
            "description": "<p>原始音频编码</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.SourceAudioSampleRate",
            "description": "<p>原始音频采样率</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "LiveQing.Body.Channels.OSD",
            "description": "<p>视频上叠加的文字</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.DeviceType",
            "description": "<p>接入协议:RTSP,ONVIF...</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.Longitude",
            "description": "<p>经度</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.Latitude",
            "description": "<p>纬度</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "LiveQing.Body.Channels.ErrorString",
            "description": "<p>错误描述</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关"
  },
  {
    "type": "get",
    "url": "/api/v1/getchannelsconfig",
    "title": "获取通道配置",
    "group": "channel",
    "name": "GetChannelsConfig",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "channel",
            "description": "<p>获取指定通道号的通道配置</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "start",
            "description": "<p>分页开始,从零开始</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "limit",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "sort",
            "description": "<p>排序字段</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "ascending",
              "descending"
            ],
            "optional": true,
            "field": "order",
            "description": "<p>排序顺序</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "q",
            "description": "<p>查询参数</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.ChannelCount",
            "description": "<p>通道配置总数</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels",
            "description": "<p>通道配置列表</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.Channels.Channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "LiveQing.Body.Channels.Enable",
            "description": "<p>是否启用</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "LiveQing.Body.Channels.OnDemand",
            "description": "<p>按需直播</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.Name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "LiveQing.Body.Channels.IP",
            "description": "<p>通道IP</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": true,
            "field": "LiveQing.Body.Channels.Port",
            "description": "<p>通道端口</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.UserName",
            "description": "<p>用户名</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.Password",
            "description": "<p>密码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "RTSP",
              "ONVIF",
              "RTMP",
              "FLV",
              "HLS",
              "FILE"
            ],
            "optional": false,
            "field": "LiveQing.Body.Channels.Protocol",
            "description": "<p>接入协议</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.Rtsp",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "LiveQing.Body.Channels.Onvif",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "LiveQing.Body.Channels.Cdn",
            "description": "<p>接入CDN 地址</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "LiveQing.Body.Channels.GBID",
            "description": "<p>国标编号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "LiveQing.Body.Channels.Audio",
            "description": "<p>开启音频</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "-1",
              "0",
              "..."
            ],
            "optional": false,
            "field": "LiveQing.Body.Channels.Record",
            "description": "<p>开启录像</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "TCP",
              "UDP"
            ],
            "optional": false,
            "field": "LiveQing.Body.Channels.Transport",
            "description": "<p>传输协议</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关"
  },
  {
    "type": "get",
    "url": "/api/v1/setchannelalarm",
    "title": "上报通道国标报警",
    "group": "channel",
    "name": "SetChannelAlarm",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "gbid",
            "description": "<p>国标编号, 该参数和通道号二选一传递即可</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "priority",
            "description": "<p>报警级别(1-一级警情,2-二级警情,3-三级警情,4-四级警情)</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "method",
            "description": "<p>报警方式(1-电话报警,2-设备报警,3-短信报警,4-GPS报警,5-视频报警,6-设备故障报警,7-其他报警)</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "time",
            "defaultValue": "now",
            "description": "<p>时间(yyyy-MM-dd HH:mm:ss)</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "description",
            "description": "<p>报警描述</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "longitude",
            "description": "<p>经度, GPS报警有效</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "latitude",
            "description": "<p>纬度, GPS报警有效</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "speed",
            "description": "<p>速度, GPS报警有效</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "direction",
            "description": "<p>方向(0~360), GPS报警有效</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/setchannelconfig",
    "title": "保存通道配置",
    "group": "channel",
    "name": "SetChannelConfig",
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "Channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "Enable",
            "description": "<p>是否启用</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "OnDemand",
            "description": "<p>按需直播</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "IP",
            "description": "<p>通道IP</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "Port",
            "description": "<p>通道端口</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "UserName",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "Password",
            "description": "<p>密码</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "RTSP",
              "ONVIF",
              "RTMP",
              "HLS"
            ],
            "optional": true,
            "field": "Protocol",
            "defaultValue": "RTSP",
            "description": "<p>接入协议</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Rtsp",
            "description": "<p>直播流地址</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "ONVIF",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "CDN",
            "description": "<p>接入 CDN 地址</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "OSD",
            "description": "<p>视频上叠加的文字</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "GBID",
            "description": "<p>国标编号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": true,
            "field": "Audio",
            "defaultValue": "0",
            "description": "<p>开启音频</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "-1",
              "0",
              "..."
            ],
            "optional": true,
            "field": "Record",
            "defaultValue": "0",
            "description": "<p>开启录像</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "TCP",
              "UDP"
            ],
            "optional": true,
            "field": "Transport",
            "defaultValue": "TCP",
            "description": "<p>传输协议</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/setchannelenable",
    "title": "设置通道禁用启用",
    "group": "channel",
    "name": "SetChannelEnable",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "enable",
            "description": "<p>是否启用</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/setchannelosd",
    "title": "设置通道OSD",
    "group": "channel",
    "name": "SetChannelOSD",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "osd",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/setchannelposition",
    "title": "设置通道位置信息",
    "group": "channel",
    "name": "SetChannelPosition",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "gbid",
            "description": "<p>国标编号, 该参数和通道号二选一传递即可</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "longitude",
            "description": "<p>经度</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "latitude",
            "description": "<p>纬度</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "time",
            "defaultValue": "now",
            "description": "<p>时间(yyyy-MM-dd HH:mm:ss)</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "speed",
            "description": "<p>速度</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "direction",
            "description": "<p>方向(0~360)</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "altitude",
            "description": "<p>海拔高度</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "push_gb_mobile_position",
            "defaultValue": "false",
            "description": "<p>上报国标移动位置</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "push_gb_alarm_position",
            "defaultValue": "false",
            "description": "<p>上报国标报警位置</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/realtime/record/start",
    "title": "开始实时录像",
    "description": "<p>录像到 MP4 文件, 停止时下载</p>",
    "group": "channel",
    "name": "StartRealtimeRecord",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/startrecord",
    "title": "开始录像",
    "description": "<p>录像到录像回看, HLS 格式</p>",
    "group": "channel",
    "name": "StartRecord",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "duration",
            "description": "<p>录像时间(秒)</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "savedays",
            "description": "<p>录像保存时长(天)</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/realtime/record/stop",
    "title": "停止实时录像",
    "description": "<p>停止实时录像并下载 MP4 文件到本地</p>",
    "group": "channel",
    "name": "StopRealtimeRecord",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK\napplication/octet-stream 格式, http body 为录像 MP4 数据",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关"
  },
  {
    "type": "get",
    "url": "/api/v1/stoprecord",
    "title": "停止录像",
    "group": "channel",
    "name": "StopRecord",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/api/v1/uploadxlsx",
    "title": "上传配置数据",
    "group": "channel",
    "name": "UploadXlsx",
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/group/channellist",
    "title": "查询分组通道列表",
    "group": "group",
    "name": "GroupChannelList",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>分组ID</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "start",
            "description": "<p>分页开始,从零开始</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "limit",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "q",
            "description": "<p>搜索关键字</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "enable",
            "description": "<p>开启状态</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "related",
            "defaultValue": "false",
            "description": "<p>是否只看已关联</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/group_api.go",
    "groupTitle": "通道分组",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ChannelCount",
            "description": "<p>通道数</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ChannelRelateCount",
            "description": "<p>已关联通道数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "ChannelList",
            "description": "<p>通道列表</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.GroupID",
            "description": "<p>分组ID</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ChannelList.Channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "ChannelList.Enable",
            "description": "<p>是否启用</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "ChannelList.OnDemand",
            "description": "<p>按需直播</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ChannelList.Name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.IP",
            "description": "<p>通道IP</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": true,
            "field": "ChannelList.Port",
            "description": "<p>通道端口</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ChannelList.UserName",
            "description": "<p>用户名</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ChannelList.Password",
            "description": "<p>密码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "RTSP",
              "ONVIF",
              "RTMP",
              "FLV",
              "HLS",
              "FILE"
            ],
            "optional": false,
            "field": "ChannelList.Protocol",
            "description": "<p>接入协议</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ChannelList.Rtsp",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.Onvif",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.Cdn",
            "description": "<p>接入CDN 地址</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.GBID",
            "description": "<p>国标编号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "ChannelList.Audio",
            "description": "<p>开启音频</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "-1",
              "0",
              "..."
            ],
            "optional": false,
            "field": "ChannelList.Record",
            "description": "<p>开启录像</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "TCP",
              "UDP"
            ],
            "optional": false,
            "field": "ChannelList.Transport",
            "description": "<p>传输协议</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/group/remove",
    "title": "分组删除",
    "group": "group",
    "name": "GroupRemove",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>分组ID</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/group_api.go",
    "groupTitle": "通道分组",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/group/save",
    "title": "分组保存",
    "group": "group",
    "name": "GroupSave",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "ID",
            "description": "<p>分组ID, 为空时表示新增, 否则为修改</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "ParentID",
            "description": "<p>父级ID</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Name",
            "description": "<p>名称</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "GBID",
            "description": "<p>国标编号</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ID",
            "description": "<p>分组ID</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/group_api.go",
    "groupTitle": "通道分组"
  },
  {
    "type": "get",
    "url": "/api/v1/group/savechannels",
    "title": "关联分组通道",
    "group": "group",
    "name": "GroupSaveChannels",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Array",
            "optional": false,
            "field": "channels",
            "description": "<p>通道列表,格式为 channel:groupid, 多个以逗号间隔, groupid为空时, 表示将通道移出分组</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/group_api.go",
    "groupTitle": "通道分组",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/group/tree",
    "title": "查询分组树",
    "group": "group",
    "name": "GroupTree",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "subfetch",
            "defaultValue": "false",
            "description": "<p>是否抓取子节点, 默认 false 即懒加载</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "pid",
            "description": "<p>父级分组ID, 传空值时, 加载顶级</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "limit",
            "defaultValue": "1000",
            "description": "<p>加载子节点数目上限, 0 表示不限制</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/group_api.go",
    "groupTitle": "通道分组",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "NodeList",
            "description": "<p>树节点列表</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "NodeList.GroupID",
            "description": "<p>分组ID, 当节点为分组时有效</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": true,
            "field": "NodeList.Channel",
            "description": "<p>通道ID, 当节点为通道时有效</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "NodeList.Name",
            "description": "<p>节点名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "NodeList.GBID",
            "description": "<p>国标编号</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "NodeList.Online",
            "description": "<p>是否在线, 当节点为通道时有效</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "NodeList.SourceVideoCodecName",
            "description": "<p>源视频编码</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": true,
            "field": "NodeList.Longitude",
            "defaultValue": "0",
            "description": "<p>经度</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": true,
            "field": "NodeList.Latitude",
            "defaultValue": "0",
            "description": "<p>纬度</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": true,
            "field": "NodeList.SubCount",
            "defaultValue": "0",
            "description": "<p>子节点数</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": true,
            "field": "NodeList.OnlineSubCount",
            "defaultValue": "0",
            "description": "<p>在线子节点数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": true,
            "field": "NodeList.Children",
            "description": "<p>子节点列表, 查询参数 subfetch = true 时有效</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/discoverdevices",
    "title": "发现设备",
    "group": "onvif",
    "name": "DiscoverDevices",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.ChannelCount",
            "description": "<p>发现设备总数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "LiveQing.Body.Channels",
            "description": "<p>设备列表</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.IP",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Channels.ONVIF",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "ONVIF 相关"
  },
  {
    "type": "get",
    "url": "/api/v1/getpresets",
    "title": "获取预置位列表",
    "group": "onvif",
    "name": "GetPresets",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.PresetsCount",
            "description": "<p>预置位总数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "LiveQing.Body.Presets",
            "description": "<p>预置位列表</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Presets.Index",
            "description": "<p>序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Presets.Name",
            "description": "<p>名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Presets.X",
            "description": "<p>X值</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Presets.Y",
            "description": "<p>Y值</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Presets.Z",
            "description": "<p>Z值</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "ONVIF 相关"
  },
  {
    "type": "get",
    "url": "/api/v1/gotopreset",
    "title": "跳转到预置位",
    "group": "onvif",
    "name": "GotoPreset",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "index",
            "description": "<p>预置位序列号</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "ONVIF 相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/ptzcontrol",
    "title": "云台控制",
    "group": "onvif",
    "name": "PTZControl",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "stop",
              "up",
              "down",
              "left",
              "right",
              "upleft",
              "upright",
              "downleft",
              "downright",
              "zoomin",
              "zoomout",
              "focusin",
              "focusout",
              "aperturein",
              "apertureout"
            ],
            "optional": false,
            "field": "command",
            "description": "<p>动作命令</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "speed",
            "description": "<p>动作速度(1~10), 例如5</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "ONVIF 相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/probedevice",
    "title": "ONVIF探测",
    "group": "onvif",
    "name": "ProbeDevice",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "IP",
            "description": "<p>发现的设备IP</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Username",
            "description": "<p>设备用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Password",
            "description": "<p>设备密码(明文)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.ONVIF",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.RTSP",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "ONVIF 相关"
  },
  {
    "type": "get",
    "url": "/api/v1/removepreset",
    "title": "删除预置位",
    "group": "onvif",
    "name": "RemovePreset",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "index",
            "description": "<p>预置位序列号</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "ONVIF 相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/setpreset",
    "title": "设置预置位",
    "group": "onvif",
    "name": "SetPreset",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "index",
            "description": "<p>预置位序列号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "name",
            "description": "<p>预置位名称</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "ONVIF 相关",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/getplan",
    "title": "获取通道录像计划",
    "group": "record",
    "name": "GetRecordPlan",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "Channel",
            "description": "<p>通道号</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "返回示例",
          "content": "{\"record\":\"1\",\"plan\":\"000000000000000000000000000010000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000010000000000000000000\"}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看"
  },
  {
    "type": "get",
    "url": "/api/v1/record/querydaily",
    "title": "按日查询通道录像",
    "group": "record",
    "name": "QueryRecordDaily",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>日期, YYYYMMDD</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "list",
            "description": "<p>当天的录像列表</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "list.name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "list.startAt",
            "description": "<p>开始时间, YYYYMMDDHHmmss</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "list.duration",
            "description": "<p>录像时长(秒)</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "list.hls",
            "description": "<p>录像播放链接</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "list.important",
            "description": "<p>重要标记</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看"
  },
  {
    "type": "get",
    "url": "/api/v1/record/querydevices",
    "title": "查询录像通道",
    "group": "record",
    "name": "QueryRecordDevices",
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "start",
            "description": "<p>分页开始,从零开始</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "limit",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "sort",
            "description": "<p>排序字段</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "ascending",
              "descending"
            ],
            "optional": true,
            "field": "order",
            "description": "<p>排序顺序</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "q",
            "description": "<p>查询参数</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "total",
            "description": "<p>总数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "rows",
            "description": "<p>分页数据</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "rows.id",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "rows.name",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "rows.updateAt",
            "description": "<p>更新时间, YYYY-MM-DD HH:mm:ss</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/queryflags",
    "title": "统计通道所有录像记录",
    "group": "record",
    "name": "QueryRecordFlags",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "key",
            "description": "<p>月份, YYYYMM</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "value",
            "description": "<p>标记当月每一天是否有录像, 0 - 没有录像, 1 - 有录像</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "成功示例",
          "content": "{201803: \"0000000011000000000000000000000\"}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看"
  },
  {
    "type": "get",
    "url": "/api/v1/record/querymonthly",
    "title": "按月查询通道录像记录",
    "group": "record",
    "name": "QueryRecordMonthly",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>月份, YYYYMM</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "flag",
            "description": "<p>标记当月每一天是否有录像, 0 - 没有录像, 1 - 有录像</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "成功示例",
          "content": "\"0000000011000000000000000000000\"",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看"
  },
  {
    "type": "get",
    "url": "/api/v1/record/download/:id/:period",
    "title": "下载录像文件",
    "group": "record",
    "name": "RecordDownload",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "play",
              "download"
            ],
            "optional": false,
            "field": "operate",
            "description": "<p>调用操作 play:播放 download下载</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>录像开始时间, YYYYMMDDHHmmss</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/video/:operate/:id/:starttime/:endtime/video.mp4",
    "title": "时间段录像播放及下载",
    "group": "record",
    "name": "RecordMP4",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "play",
              "download"
            ],
            "optional": false,
            "field": "operate",
            "description": "<p>调用操作 play:播放 download下载</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "starttime",
            "description": "<p>开始时间, YYYYMMDDHHmmss</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "endtime",
            "description": "<p>结束时间, YYYYMMDDHHmmss</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "播放示例",
          "content": "http://localhost:10800/api/v1/record/video/play/1/20180911101139/20180911101248/video.mp4",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "下载示例",
          "content": "http://localhost:10800/api/v1/record/video/download/1/20180911101139/20180911101248/video.mp4",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看"
  },
  {
    "type": "get",
    "url": "/api/v1/record/remove",
    "title": "删除单条录像",
    "group": "record",
    "name": "RemoveRecord",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>录像开始时间, YYYYMMDDHHmmss</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/removedevice",
    "title": "删除通道所有录像",
    "group": "record",
    "name": "RemoveRecordByDevice",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/removedaily",
    "title": "按天删除通道录像",
    "group": "record",
    "name": "RemoveRecordDaily",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>日期, YYYYMMDD</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/setimportant",
    "title": "重要录像标记",
    "group": "record",
    "name": "SetRecordImportant",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>录像开始时间, YYYYMMDDHHmmss</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "important",
            "description": "<p>重要标记</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/v1/record/setplan",
    "title": "保存通道录像计划",
    "group": "record",
    "name": "SetRecordPlan",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "endchannel",
            "description": "<p>范围截止通道号，若传递需大于channel值，表示配置 [channel,endchannel] 这个区间里的所有通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "plan",
            "description": "<p>录像时段，336位2进制数（分别对应一周每天24小时前半小时和后半小时），0表示不存储，1表示存储 ,默认全部时间段保存录像</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": true,
            "field": "record",
            "description": "<p>录像保留天</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record_api.go",
    "groupTitle": "录像回看",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "订阅",
    "url": "订阅通道状态",
    "title": "订阅通道状态",
    "group": "redis",
    "name": "SubscribeChannel",
    "header": {
      "examples": [
        {
          "title": "指令:",
          "content": "subscribe channel",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "上线消息",
          "content": "\"channel\"\n\"1 ON\"",
          "type": "json"
        },
        {
          "title": "离线消息",
          "content": "\"channel\"\n\"1 OFF\"",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "REDIS订阅"
  },
  {
    "type": "配置",
    "url": "配置连接REDIS",
    "title": "配置连接REDIS",
    "group": "redis",
    "name": "SubscribeRedis",
    "header": {
      "examples": [
        {
          "title": "LiveNVR配置连接REDIS 示例:",
          "content": "在解压目录下 livenvr.ini 里配置，添加[redis]配置块 ，如：\n\n[redis]\nhost=127.0.0.1\nport=6379\npassword=test",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "REDIS订阅"
  },
  {
    "type": "get",
    "url": "/api/v1/getserverinfo",
    "title": "获取平台运行信息",
    "group": "sys",
    "name": "GetServerInfo",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Authorization",
            "description": "<p>授权对象</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Hardware",
            "description": "<p>硬件信息</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.InterfaceVersion",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "LiveQing.Body.IsDemo",
            "description": "<p>演示版本</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "LiveQing.Body.LiveSteamAuth",
            "description": "<p>直播页面鉴权</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.RemainDays",
            "description": "<p>剩余授权时间(天)</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.RunningTime",
            "description": "<p>运行时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.ServerTime",
            "description": "<p>系统时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.StartUpTime",
            "description": "<p>启动时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Server",
            "description": "<p>软件信息</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.ChannelCount",
            "description": "<p>通道数</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.VersionType",
            "description": "<p>版本类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.LogoText",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.LogoMiniText",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.CopyrightText",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口"
  },
  {
    "type": "get",
    "url": "/api/v1/getuserinfo",
    "title": "获取当前登录用户信息",
    "group": "sys",
    "name": "GetUserInfo",
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.id",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.name",
            "description": "<p>用户名</p>"
          },
          {
            "group": "200",
            "type": "String[]",
            "optional": true,
            "field": "LiveQing.Body.roles",
            "description": "<p>角色列表</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": true,
            "field": "LiveQing.Body.hasAllChannel",
            "description": "<p>是否关联所有通道</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/login",
    "title": "登录",
    "group": "sys",
    "name": "Login",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>密码(经过md5加密,32位长度,不带中划线,不区分大小写)</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": true,
            "field": "url_token_only",
            "description": "<p>是否只获取URLToken, 默认值 false, 推荐获取 URLToken 时带 url_token_only=true, 将不会入库持久 session, 减少库表操作</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.CookieToken",
            "description": "<p>用于方式一的鉴权</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.URLToken",
            "description": "<p>用于方式二的鉴权</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.TokenTimeout",
            "description": "<p>Token 超时(秒)</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Token",
            "description": "<p>等同于 CookieToken, 为了兼容保留</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200\n{\"URLToken\":\"slkdfjiw2ej.jskdfwe-wefadsf.sdfwoeuyqtew\", \"CookieToken\":\"mDC4tu-ig\", \"TokenTimeout\":604800}\n\n鉴权方式一：\nSet-Cookie: token=mDC4tu-ig; Path=/; Expires=Thu, 15 Nov 2018 03:13:26 GMT; Max-Age=604800; HttpOnly\n\n鉴权方式二：\n接口统一增加入参名 token, 传递值为返回的 URLToken\nhttp://ip:port/api/v1/xxx?token=slkdfjiw2ej.jskdfwe-wefadsf.sdfwoeuyqtew&otherparam=xxx",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口"
  },
  {
    "type": "get",
    "url": "/api/v1/logout",
    "title": "登出",
    "name": "Logout",
    "group": "sys",
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/modifypassword",
    "title": "修改密码",
    "group": "sys",
    "name": "ModifyPassword",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "oldpassword",
            "description": "<p>旧密码, MD5密文</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "newpassword",
            "description": "<p>新密码, MD5密文</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.CookieToken",
            "description": "<p>用于方式一的鉴权</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.URLToken",
            "description": "<p>用于方式二的鉴权</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "LiveQing.Body.TokenTimeout",
            "description": "<p>Token 超时(秒)</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Body.Token",
            "description": "<p>等同于 CookieToken, 为了兼容保留</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LiveQing.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "LiveQing.Body",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200\n{\"URLToken\":\"slkdfjiw2ej.jskdfwe-wefadsf.sdfwoeuyqtew\", \"CookieToken\":\"mDC4tu-ig\", \"TokenTimeout\":604800}\nSet-Cookie: token=mDC4tu-ig; Path=/; Expires=Thu, 15 Nov 2018 03:13:26 GMT; Max-Age=604800; HttpOnly",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口"
  },
  {
    "type": "get",
    "url": "/api/v1/restart",
    "title": "重启服务",
    "group": "sys",
    "name": "Restart",
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/user/channellist",
    "title": "查询用户通道列表",
    "group": "user",
    "name": "UserChannelList",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "start",
            "description": "<p>分页开始,从零开始</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "limit",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "q",
            "description": "<p>搜索关键字</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "enable",
            "description": "<p>开启状态</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "related",
            "defaultValue": "false",
            "description": "<p>是否只看已关联</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ChannelCount",
            "description": "<p>通道数</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ChannelRelateCount",
            "description": "<p>已关联通道数</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "HasAllChannel",
            "description": "<p>是否关联所有通道</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "ChannelList",
            "description": "<p>通道列表</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.UserID",
            "description": "<p>用户ID, 有值时, 表示该通道已关联</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ChannelList.Channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "ChannelList.Enable",
            "description": "<p>是否启用</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "ChannelList.OnDemand",
            "description": "<p>按需直播</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ChannelList.Name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.IP",
            "description": "<p>通道IP</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": true,
            "field": "ChannelList.Port",
            "description": "<p>通道端口</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ChannelList.UserName",
            "description": "<p>用户名</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ChannelList.Password",
            "description": "<p>密码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "RTSP",
              "ONVIF"
            ],
            "optional": false,
            "field": "ChannelList.Protocol",
            "description": "<p>接入协议</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ChannelList.Rtsp",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.Onvif",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.Cdn",
            "description": "<p>接入CDN 地址</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "ChannelList.GBID",
            "description": "<p>国标编号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "ChannelList.Audio",
            "description": "<p>开启音频</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "-1",
              "0",
              "..."
            ],
            "optional": false,
            "field": "ChannelList.Record",
            "description": "<p>开启录像</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "TCP",
              "UDP"
            ],
            "optional": false,
            "field": "ChannelList.Transport",
            "description": "<p>传输协议</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/user/info",
    "title": "查询用户信息",
    "group": "user",
    "name": "UserInfo",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>用户名, 该参数和用户ID二选一传递即可</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ID",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "Username",
            "description": "<p>用户名</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "Role",
            "description": "<p>角色, 多个角色以逗号间隔</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "Creator",
            "description": "<p>创建者</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "Enable",
            "description": "<p>是否启用</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "HasAllChannel",
            "description": "<p>是否关联所有通道</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "LastLoginAt",
            "description": "<p>最近登录时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "UpdatedAt",
            "description": "<p>更新时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "CreatedAt",
            "description": "<p>创建时间</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/user/list",
    "title": "查询用户列表",
    "group": "user",
    "name": "UserList",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "start",
            "description": "<p>分页开始,从零开始</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "limit",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "q",
            "description": "<p>搜索关键字</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "enable",
            "description": "<p>启用状态</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "UserCount",
            "description": "<p>用户总数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "UserList",
            "description": "<p>用户列表</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "UserList.ID",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "UserList.Username",
            "description": "<p>用户名</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "UserList.Role",
            "description": "<p>角色, 多个角色以逗号间隔</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "UserList.Creator",
            "description": "<p>创建者</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "UserList.Enable",
            "description": "<p>是否启用</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "UserList.HasAllChannel",
            "description": "<p>是否关联所有通道</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "UserList.LastLoginAt",
            "description": "<p>最近登录时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "UserList.UpdatedAt",
            "description": "<p>更新时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "UserList.CreatedAt",
            "description": "<p>创建时间</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/user/remove",
    "title": "用户删除",
    "group": "user",
    "name": "UserRemove",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>用户ID, 多个以逗号间隔</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/user/removechannels",
    "title": "设置用户移除关联通道",
    "group": "user",
    "name": "UserRemoveChannels",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "Parameter",
            "type": "Array",
            "optional": false,
            "field": "channels",
            "description": "<p>通道列表, 多个以逗号间隔</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/user/resetpassword",
    "title": "用户重置密码",
    "group": "user",
    "name": "UserResetPassword",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>用户名, 该参数和用户ID二选一传递即可</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>密码</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "cipherpwd",
            "defaultValue": "false",
            "description": "<p>密码是否是密文</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/user/save",
    "title": "用户保存",
    "group": "user",
    "name": "UserSave",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "ID",
            "description": "<p>用户ID, 0表示新增, 否则为修改</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Username",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Role",
            "description": "<p>用户角色,多个角色以逗号间隔</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": true,
            "field": "Enable",
            "defaultValue": "true",
            "description": "<p>是否启用</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ID",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "DefaultUserPassword",
            "description": "<p>新增用户初始密码</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理"
  },
  {
    "type": "get",
    "url": "/api/v1/user/savechannels",
    "title": "用户保存关联通道",
    "group": "user",
    "name": "UserSaveChannels",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "Parameter",
            "type": "Array",
            "optional": false,
            "field": "channels",
            "description": "<p>通道列表, 多个以逗号间隔</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/user/setenable",
    "title": "设置用户启用状态",
    "group": "user",
    "name": "UserSetEnable",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>用户名, 该参数和用户ID二选一传递即可</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": false,
            "field": "enable",
            "description": "<p>是否启用</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/user/sethasallchannel",
    "title": "设置用户关联所有通道",
    "group": "user",
    "name": "UserSetHasAllChannel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>用户名, 该参数和用户ID二选一传递即可</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "true",
              "false"
            ],
            "optional": false,
            "field": "hasallchannel",
            "description": "<p>是否关联所有通道</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/user_api.go",
    "groupTitle": "用户管理",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  }
] });
