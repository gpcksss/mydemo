1、LiveNVR 使用说明

 - https://www.liveqing.com/docs/manuals/LiveNVR.html

2、LiveNVR 二次开发接口

 - 在线接口文档：https://nvr.liveqing.com:10810/apidoc

 - 本地服务接口访问：http://127.0.0.1:10800/apidoc

 - 离线访问：浏览器打开 www/apidoc/index.html

3、LiveNVR 常见问题

 - https://www.liveqing.com/docs/faq/LiveNVR.html